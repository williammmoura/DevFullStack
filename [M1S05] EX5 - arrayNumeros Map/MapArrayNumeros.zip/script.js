var arrayNumerico = [1, 2, 3, 4, 5, 6, 7, 8, 9];

var arrayImpar = [];

const quadrado = numeros => numeros.map(x => x ** 2);

console.log(arrayNumerico);
console.log(quadrado(arrayNumerico));
