const mensagemOla = () => {
  return 'Olá Mundo!!!';
};

console.log(mensagemOla());
