var arrayNumerico = [1, 2, 3, 4, 5, 6, 7, 8, 9];

var arrayInvertido = [];

const invertArray = array => {
  return array.reverse();
};

console.log(arrayNumerico);
console.log(invertArray(arrayNumerico));
