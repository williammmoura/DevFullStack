var arrayNumerico = [1, 2, 3, 4, 5, 6, 7, 8, 9];

var arrayImpar = [];

const impares = numeros => numeros.filter(x => x % 2 != 0);

console.log(arrayNumerico);
console.log(impares(arrayNumerico));
