const mensagemOla = nome => {
  return `Olá ${nome}`;
};

console.log(mensagemOla('Zezinho'));
